# S22_textinput_JS

A Pen created on CodePen.

Original URL: [https://codepen.io/bryan4ian-yt/pen/GgZBxGN](https://codepen.io/bryan4ian-yt/pen/GgZBxGN).

